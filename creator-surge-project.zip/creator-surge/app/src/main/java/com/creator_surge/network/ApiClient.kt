package com.creator_surge.network

import com.creator_surge.model.CreationResult
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

object ApiClient {
    // Replace with your deployed Render URL, with no trailing slash.
    const val BASE_URL = "https://YOUR-RENDER-SERVICE.onrender.com"
    private val client = OkHttpClient()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun create(prompt: String): CreationResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        require(!BASE_URL.contains("YOUR-RENDER-SERVICE")) { "Set ApiClient.BASE_URL to your Render service URL first." }
        val body = JSONObject().put("prompt", prompt).put("mediums", JSONArray(listOf("image", "video", "game", "code", "docs"))).toString()
        val request = Request.Builder().url("$BASE_URL/create").post(body.toRequestBody("application/json".toMediaType())).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            check(response.isSuccessful) { "API error ${response.code}: $raw" }
            json.decodeFromString<CreationResult>(raw)
        }
    }
}
